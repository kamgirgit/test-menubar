import "./App.css";
import MenuBar from "./MenuBar";

function App() {
  return (
    <div className='App'>
      <MenuBar />
    </div>
  );
}

export default App;
